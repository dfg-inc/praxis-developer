# Praxis Developer

Claude UI / Cowork plugin for Praxis 0.1.0-alpha.29.

Praxis Developer requires:
- a supported Claude workspace / Cowork execution surface with project access
- access to the product repository
- Jira configuration available in the local runtime (environment or `.env.praxis`)

Do not paste Jira tokens into chat. Do not run `praxis`, `make`, or `npm` to use this plugin.

Primary workflow: invoke a role Skill and speak naturally. Praxis operations run through bundled MCP tools (`runtime/praxis-mcp.cjs`), not a CLI.

Claude Chat may show Skills, but local edit/test flow needs workspace/runtime capabilities. If the repository or local runtime is unavailable the tools return `REPOSITORY_UNAVAILABLE` or `LOCAL_RUNTIME_UNAVAILABLE` instead of pretending work ran.
